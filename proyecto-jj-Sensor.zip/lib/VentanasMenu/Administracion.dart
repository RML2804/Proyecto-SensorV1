import 'package:flutter/material.dart';

class Administracion extends StatefulWidget {
  const Administracion({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => InitState();
}

class InitState extends State<Administracion> {
  @override
  Widget build(BuildContext context) {
    return initWidget();
  }

  Widget initWidget() {
    return Scaffold(
      body: Container(
        //color: Colors.lightBlue.shade900,

        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            Colors.blue,
            Colors.lightBlue.shade900,
          ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        ),

        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "Administracion",
              style: TextStyle(color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
