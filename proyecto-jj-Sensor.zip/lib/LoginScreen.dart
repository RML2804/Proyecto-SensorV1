import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'RegisterScreen.dart';
import 'MainNavigationBar.dart';
import 'package:firebase_database/firebase_database.dart';

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter_email_sender/flutter_email_sender.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => InitState();
}

class InitState extends State<LoginScreen> {
  String UserValue = "Alumno";
  bool obs = true;

  final TextEditingController IDController = TextEditingController();
  final TextEditingController ContrasenaController = TextEditingController();
  late FocusNode FocusID, FocusContrasena;

  @override
  void initState() {
    super.initState();
    FocusID = FocusNode();
    FocusContrasena = FocusNode();
  }

  @override
  void dispose() {
    FocusID.dispose();
    FocusContrasena.dispose();
    IDController.dispose();
    ContrasenaController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return initWidget();
  }

  void IrNavegador() {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => MainNavigationBar()));
  }

  void ConsultaEspecifica() async {
    String idCampo = IDController.text.toString();
    String ContrasenaCampo = ContrasenaController.text.toString();
    var Contrasena;

    final ref = FirebaseDatabase.instance.ref();
    final snapshot =
        await ref.child('Acceso').child(UserValue).child('$idCampo').get();

    if (snapshot.exists) {
      Contrasena = snapshot.child('contrasena').value;

      if (Contrasena == ContrasenaCampo) {
        IDController.clear();
        FocusID.unfocus();
        ContrasenaController.clear();
        FocusContrasena.unfocus();

        IrNavegador();
      } else {
        DialogoWarning('Contraseña incorrecta');
        FocusID.unfocus();
        FocusContrasena.requestFocus();
      }
    } else {
      DialogoWarning('$UserValue no registrado');
      FocusContrasena.unfocus();
      FocusID.requestFocus();
    }
  }

  void DialogoWarning(String Detalle) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('LOGIN'),
          content: Text('$Detalle'),
          backgroundColor: Colors.yellow[200], // Cambia el color de fondo aquí
          actions: [
            TextButton(
              child: Text('ACEPTAR'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void validarCampos() {
    String id = IDController.text.trim();
    String contrasena = ContrasenaController.text.trim();

    if (id.isEmpty || contrasena.isEmpty) {
      AwesomeDialog(
        context: context,
        dialogType: DialogType.warning,
        animType: AnimType.rightSlide,
        title: 'Campos vacíos',
        desc: 'Por favor, complete todos los campos.',
        btnOkOnPress: () {},
      ).show();
    } else {
      // Aquí puedes continuar con el inicio de sesión o navegación
      IrNavegador();
    }
  }

  Future<void> sendEmail() async {
    final Email email = Email(
      body: 'Este es el cuerpo del correo.',
      subject: 'Asunto del Correo',
      recipients: ['MunozMerazJoseAlfredo@gmail.com'],
      cc: ['jose.munoz@itson.edu.mx'],
      bcc: ['jose.munoz243499@potros.itson.edu.mx'],
      attachmentPaths: [],
      isHTML: false,
    );

    try {
      await FlutterEmailSender.send(email);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Correo enviado')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al enviar el correo: $e')));
    }
  }

  void DialogoMail() {
    AwesomeDialog(
      context: context,
      animType: AnimType.bottomSlide,
      dialogType: DialogType.info,
      headerAnimationLoop: false,
      dialogBorderRadius: BorderRadius.all(Radius.circular(30)),
      dialogBackgroundColor: Colors.white,
      borderSide: const BorderSide(
        color: Colors.orangeAccent,
        width: 3,
      ),
      barrierColor: Colors.orangeAccent.withOpacity(0.3),
      showCloseIcon: true,
      dismissOnTouchOutside: true,
      dismissOnBackKeyPress: false,
      keyboardAware: true,
      body: Padding(
        padding: const EdgeInsets.all(5),
        child: Column(
          children: <Widget>[
            Container(
              height: 50,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(15),
                  topLeft: Radius.circular(15),
                ),
                gradient: LinearGradient(
                    colors: [Colors.orange.shade800, Colors.orangeAccent],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight),
                boxShadow: [
                  BoxShadow(
                      offset: Offset(0, -3), blurRadius: 10, color: Colors.grey)
                ],
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      child: Text("Recupera tu contraseña",
                          style: TextStyle(fontSize: 16, color: Colors.white)),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Material(
              elevation: 0,
              color: Colors.orange.withAlpha(40),
              child: TextFormField(
                autofocus: true,
                minLines: 1,
                maxLines: 1,
                cursorColor: Colors.orange.shade900,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  labelText: 'ID',
                  labelStyle: TextStyle(color: Colors.orange.shade900),
                  prefixIcon: Icon(Icons.admin_panel_settings,
                      color: Colors.orange.shade900),
                ),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Material(
              elevation: 0,
              color: Colors.orange.withAlpha(40),
              child: TextFormField(
                autofocus: true,
                minLines: 1,
                maxLines: 1,
                cursorColor: Colors.orange.shade900,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  labelText: 'Correo Electrónico',
                  labelStyle: TextStyle(color: Colors.orange.shade900),
                  prefixIcon: Icon(Icons.contact_mail_rounded,
                      color: Colors.orange.shade900),
                ),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            GestureDetector(
              onTap: () => {sendEmail},
              child: Container(
                alignment: Alignment.center,
                height: 45,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [Colors.orange.shade800, Colors.orangeAccent],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(15),
                    bottomRight: Radius.circular(15),
                  ),
                  boxShadow: [
                    BoxShadow(
                        offset: Offset(0, 3),
                        blurRadius: 10,
                        color: Colors.grey)
                  ],
                ),
                child: Text(
                  "RECUPERAR",
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
            SizedBox(
              height: 15,
            ),
          ],
        ),
      ),
    ).show();
  }

  Widget initWidget() {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 300,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(100),
                ),
                color: Colors.orange.shade900,
                gradient: LinearGradient(
                  colors: [Colors.orange, Colors.orange.shade900],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 60),
                      child: Image.asset("assets/images/logo.png"),
                      height: 120,
                      width: 150,
                    ),
                    Container(
                      child: Text("Iniciar Sesión",
                          style: TextStyle(fontSize: 18, color: Colors.white)),
                    ),
                  ],
                ),
              ),
            ),
            //--------------------------------------------------------
            Container(
              margin: EdgeInsets.only(left: 115, right: 115, top: 25),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                boxShadow: [
                  BoxShadow(
                      offset: Offset(0, 3),
                      blurRadius: 5,
                      color: Colors.grey.shade400)
                ],
              ),
            ),
            //--------------------------------------------------------
            Container(
              margin: EdgeInsets.only(left: 20, right: 20, top: 25),
              padding: EdgeInsets.only(left: 20, right: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Colors.grey[300],
                boxShadow: [
                  BoxShadow(
                      offset: Offset(0, 3), blurRadius: 10, color: Colors.grey)
                ],
              ),
              alignment: Alignment.center,
              child: TextField(
                controller: IDController,
                cursorColor: Colors.orange.shade900,
                decoration: InputDecoration(
                    icon: Icon(
                      Icons.admin_panel_settings,
                      color: Colors.orange.shade900,
                    ),
                    hintText: "ID",
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none),
              ),
            ),
            //--------------------------------------------------------
            Container(
              margin: EdgeInsets.only(left: 20, right: 20, top: 25),
              padding: EdgeInsets.only(left: 20, right: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Colors.grey[300],
                boxShadow: [
                  BoxShadow(
                      offset: Offset(0, 3), blurRadius: 10, color: Colors.grey)
                ],
              ),
              alignment: Alignment.center,
              child: TextFormField(
                controller: ContrasenaController,
                obscureText: obs,
                cursorColor: Colors.orange.shade900,
                decoration: InputDecoration(
                  icon: Icon(
                    Icons.vpn_key,
                    color: Colors.orange.shade900,
                  ),
                  hintText: "Contraseña",
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  suffixIcon: IconButton(
                    icon: Icon(
                      Icons.remove_red_eye,
                      color: Colors.orange.shade900,
                    ),
                    onPressed: () {
                      setState(() {
                        obs == false ? obs = true : obs = false;
                      });
                    },
                  ),
                ),
              ),
            ),
            //--------------------------------------------------------
            Container(
              margin: EdgeInsets.only(right: 30, top: 25),
              alignment: Alignment.centerRight,
              child: GestureDetector(
                child: Text(
                  "Recuperar Contraseña",
                  style: TextStyle(color: Colors.orange.shade900),
                ),
                onTap: () => {DialogoMail()},
              ),
            ),
            //--------------------------------------------------------
            GestureDetector(
              onTap: () => {
                ConsultaEspecifica()
                //IrNavegador()
              },
              child: Container(
                margin: EdgeInsets.only(left: 35, right: 35, top: 40),
                padding: EdgeInsets.only(left: 20, right: 20),
                alignment: Alignment.center,
                height: 50,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [Colors.orange, Colors.orange.shade900],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight),
                  borderRadius: BorderRadius.circular(50),
                  boxShadow: [
                    BoxShadow(
                        offset: Offset(0, 3),
                        blurRadius: 10,
                        color: Colors.grey)
                  ],
                ),
                child: Text("ACCEDER", style: TextStyle(color: Colors.white)),
              ),
            ),
            //--------------------------------------------------------
            Container(
              margin: EdgeInsets.only(top: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("¿No tienes una cuenta? "),
                  GestureDetector(
                    onTap: () => {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => RegisterScreen(),
                        ),
                      )
                    },
                    child: Text("Registrarse",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.orange.shade900)),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
