import 'dart:async';
import 'package:flutter/material.dart';
import 'LoginScreen.dart';

class SplashScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => InitState();
}

class InitState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {
    return initWidget();
  }

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  startTimer() async {
    var duracion = Duration(seconds: 3);
    return new Timer(duracion, irlogin);
  }

  irlogin() {
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => LoginScreen()));
  }

  Widget initWidget() {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.lightGreen.shade900,
              gradient: LinearGradient(
                  colors: [Colors.orange, Colors.lightGreen.shade900],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter),
            ),
          ),
          Center(
            child: Container(
              child: Image.asset("assets/images/logo.png"),
            ),
          ),
        ],
      ),
    );
  }
}
