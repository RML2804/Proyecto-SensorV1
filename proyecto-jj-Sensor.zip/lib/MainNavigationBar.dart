import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';

import 'VentanasMenu/Inicio.dart';
import 'VentanasMenu/Perfil.dart';
import 'VentanasMenu/Administracion.dart';
import 'LoginScreen.dart';

class MainNavigationBar extends StatefulWidget {
  const MainNavigationBar({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => InitState();
}

class InitState extends State<MainNavigationBar> {
  String Titulo = "Inicio";

  @override
  Widget build(BuildContext context) {
    return initWidget();
  }

  int _currentIndex = 1;
  final List<Widget> _children = [
    Perfil(),
    Inicio(),
    Administracion(),
  ];

  void OnTappedBar(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  Widget initWidget() {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // oculta la flecha para regresar
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.topRight,
              colors: [
                Colors.blue.shade900,
                Colors.purple.shade600,
              ],
            ),
          ),
        ),
        title: Text(
          "$Titulo",
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: _currentIndex == 1
          ? Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue.shade900, Colors.purple.shade600],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.thermostat,
                      size: 100,
                      color: Colors.white,
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Bienvenido al sistema de monitoreo',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Temperatura y Humedad en tiempo real',
                      style: TextStyle(
                        fontSize: 18,
                        color: Colors.white70,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: () {
                        // Redirige al LoginScreen y reemplaza la pantalla actual
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => LoginScreen()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.blue.shade900,
                        padding:
                            EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(
                        'Cerrar sesión',
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ],
                ),
              ),
            )
          : _children[
              _currentIndex], // Muestra la pantalla correspondiente si no es la de inicio
      bottomNavigationBar: CurvedNavigationBar(
        color: Colors.white,
        backgroundColor: Colors.blue.shade900,
        buttonBackgroundColor: Colors.white,
        height: 50, // altura desde los botones de android hasta el navbar
        items: <Widget>[
          Icon(Icons.list, size: 25, color: Colors.blue.shade900),
          Icon(Icons.home, size: 25, color: Colors.blue.shade900),
          Icon(Icons.person, size: 25, color: Colors.blue.shade900),
        ],
        animationDuration: Duration(milliseconds: 200),
        index: 1,
        animationCurve: Curves.bounceInOut,
        onTap: (index) {
          OnTappedBar(index);

          if (index == 0) {
            Titulo = "Perfil";
          }

          if (index == 1) {
            Titulo = "Inicio";
          }

          if (index == 2) {
            Titulo = "Administracion";
          }
        },
      ),
    );
  }
}
