import 'package:flutter/material.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:quickalert/quickalert.dart';

class RegisterScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => InitState();
}

class InitState extends State<RegisterScreen> {
  String UserValue = "Alumno";
  String CarreraValue = "Licenciatura en Administración";
  bool obs = true;

  final TextEditingController IDController = TextEditingController();
  final TextEditingController NombreController = TextEditingController();
  final TextEditingController ContrasenaController = TextEditingController();

  late FocusNode FocusID, FocusNombre, FocusCarrera, FocusContrasena;

  @override
  Widget build(BuildContext context) {
    return initWidget();
  }

  void ConsultaEspecifica() async {
    String idCampo = IDController.text.toString();
    var ID;
    final ref = FirebaseDatabase.instance.ref();
    final snapshot =
        await ref.child(UserValue).child(CarreraValue).child('$idCampo').get();

    if (snapshot.exists) {
      ID = snapshot.key;
      DialogoWarning('El $UserValue Ya se encuentra registrado');
      //print('El $UserValue Ya se encuentra registrado');
    } else {
      DialogoQuestion();
    }
  }

  void DialogoWarning(String Detalle) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Registro'),
          content: Text('$Detalle'),
          backgroundColor: Colors.yellow[200], // Cambia el color de fondo aquí
          actions: [
            TextButton(
              child: Text('ACEPTAR'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void DialogoQuestion() {
    QuickAlert.show(
        context: context,
        type: QuickAlertType.confirm,
        animType: QuickAlertAnimType.slideInDown,
        barrierDismissible: true,
        title: '',
        text: '¿Deseas registrarte?',
        confirmBtnText: 'Sí',
        cancelBtnText: 'No',
        confirmBtnColor: Colors.green,
        onConfirmBtnTap: () async {
          //RegistrarAcceso();
          RegistrarPrueba();
          RestablecerCampos();

          Navigator.pop(context);
          await Future.delayed(const Duration(milliseconds: 500));
          await QuickAlert.show(
            context: context,
            type: QuickAlertType.success,
            title: '$UserValue registrado',
            confirmBtnText: 'ACEPTAR',
          );
        });
  }

  void RegistrarPrueba() {
    setState(() {
      final datos = FirebaseDatabase.instance.ref();
      datos.child(UserValue).child(CarreraValue).child(IDController.text).set({
        'Nombre': NombreController.text,
        'Contrasena': ContrasenaController.text,
      });
    });
  }

  void RestablecerCampos() {
    IDController.clear();
    FocusID.unfocus();
    NombreController.clear();
    FocusNombre.unfocus();
    CarreraValue = "Licenciatura en Administración";
    FocusCarrera.unfocus();
    ContrasenaController.clear();
    FocusContrasena.unfocus();
  }

  Widget initWidget() {
    FocusID = FocusNode();
    FocusNombre = FocusNode();
    FocusCarrera = FocusNode();
    FocusContrasena = FocusNode();

    return Scaffold(
      //body: SingleChildScrollView(
      body: WillPopScope(
        onWillPop: () async {
          bool confirm = await showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text("¿Desea salir de esta pantalla?"),
                actions: <Widget>[
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: Text("No"),
                  ),
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    child: Text("Sí"),
                  ),
                ],
              );
            },
          );
          return confirm;
        },
        child: Column(
          children: [
            //------------------------------------------------------------------
            //CABECERA
            Container(
              height: 250,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(15),
                    bottomRight: Radius.circular(15)),
                color: Colors.lightBlue.shade900,
                gradient: LinearGradient(
                    colors: [Colors.blue, Colors.lightBlue.shade900],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 70),
                      child: Image.asset("assets/images/logoitson.png"),
                      height: 100,
                      width: 100,
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 0),
                      alignment: Alignment.bottomCenter,
                      //margin: EdgeInsets.only(right: 20, top: 0),
                      //alignment: Alignment.bottomRight,

                      child: Text(
                        "Registro de usuario",
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    )
                  ],
                ),
              ),
            ),
            //--------------------------------------------------------
            // SWITCH DE EMPLEADO - ALUMNO
            Container(
              margin: EdgeInsets.only(left: 115, right: 115, top: 25),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                //color: Colors.grey[300],
                boxShadow: [
                  BoxShadow(
                      offset: Offset(0, 3),
                      blurRadius: 5,
                      color: Colors.grey.shade400)
                ],
              ),
              //alignment: Alignment.center,
              child: Padding(
                padding: const EdgeInsets.only(top: 5),
                child: LiteRollingSwitch(
                  value: false,
                  width: 130,
                  textSize: 13,
                  textOn: 'Empleado',
                  textOnColor: Colors.white,
                  colorOn: Colors.lightBlue.shade800,
                  iconOn: Icons.person_pin_rounded,
                  textOff: 'Alumno',
                  colorOff: Colors.lightBlue.shade800,
                  iconOff: Icons.supervised_user_circle_rounded,
                  animationDuration: const Duration(milliseconds: 300),
                  onChanged: (bool State) {
                    if (State == false) {
                      UserValue = "Alumno";
                    } else {
                      UserValue = "Empleado";
                    }
                    print(UserValue);
                  },
                  onDoubleTap: () {},
                  onSwipe: () {},
                  onTap: () {},
                ),
              ),
            ),
            //--------------------------------------------------------
            // CAMPO ID
            Container(
              margin: EdgeInsets.only(left: 20, right: 20, top: 25),
              padding: EdgeInsets.only(left: 20, right: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Colors.grey[300],
                boxShadow: [
                  BoxShadow(
                      offset: Offset(0, 3), blurRadius: 10, color: Colors.grey)
                ],
              ),
              alignment: Alignment.center,
              child: TextField(
                focusNode: FocusID,
                controller: IDController,
                cursorColor: Colors.lightBlue.shade900,
                decoration: InputDecoration(
                    icon: Icon(
                      Icons.admin_panel_settings,
                      color: Colors.lightBlue.shade900,
                    ),
                    hintText: "ID",
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none),
              ),
            ),
            //--------------------------------------------------------
            // CAMPO NOMBRE
            Container(
              margin: EdgeInsets.only(left: 20, right: 20, top: 25),
              padding: EdgeInsets.only(left: 20, right: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Colors.grey[300],
                boxShadow: [
                  BoxShadow(
                      offset: Offset(0, 3), blurRadius: 10, color: Colors.grey)
                ],
              ),
              alignment: Alignment.center,
              child: TextField(
                focusNode: FocusNombre,
                controller: NombreController,
                cursorColor: Colors.lightBlue.shade900,
                decoration: InputDecoration(
                    icon: Icon(
                      Icons.person,
                      color: Colors.lightBlue.shade900,
                    ),
                    hintText: "NOMBRE",
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none),
              ),
            ),
            //--------------------------------------------------------
            // CAMPO CARRERA
            Container(
              margin: EdgeInsets.only(left: 20, right: 20, top: 25),
              padding: EdgeInsets.only(left: 20, right: 20),
              height: 75,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.grey[300],
                boxShadow: [
                  BoxShadow(
                      offset: Offset(0, 3), blurRadius: 10, color: Colors.grey)
                ],
              ),
              alignment: Alignment.center,
              child: DropdownButtonFormField(
                focusNode: FocusCarrera,
                isExpanded: true,
                isDense: false,
                menuMaxHeight: 500,
                decoration: InputDecoration(
                    icon: Icon(
                      Icons.badge_sharp,
                      color: Colors.lightBlue.shade900,
                    ),
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none),
                borderRadius: BorderRadius.circular(10),
                dropdownColor: Colors.grey[300],
                value: CarreraValue,
                onChanged: (String? newValue) {
                  setState(() {
                    CarreraValue = newValue!;
                    print(CarreraValue);
                  });
                },
                items: <String>[
                  'Licenciatura en Administración',
                  'Licenciatura en Administración de Empresas Turísticas',
                  'Licenciatura en Administración Estratégica',
                  'Licenciatura en Arquitectura',
                  'Licenciatura en Ciencias de la Educación',
                  'Licenciatura en Ciencias del Ejercicio Físico',
                  'Licenciatura en Contaduría Pública',
                  'Licenciatura en Diseño Gráfico',
                  'Licenciatura en Derecho',
                  'Licenciatura en Economía y Finanzas',
                  'Licenciatura en Educación Infantil',
                  'Licenciatura en Enfermería',
                  'Licenciatura en Gastronomía',
                  'Licenciatura en Mercadotecnia',
                  'Licenciatura en Psicología',
                  'Ingeniería en Biosistemas',
                  'Ingeniería en Logística​',
                  'Ingeniería en Manufactura',
                  'Ingeniería en Software',
                  'Ingeniería Industrial y de Sistemas'
                ].map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(
                      value,
                      style: TextStyle(fontSize: 15),
                    ),
                  );
                }).toList(),
              ),
            ),
            //--------------------------------------------------------
            // CAMPO CONTRASEÑA
            Container(
              margin: EdgeInsets.only(left: 20, right: 20, top: 25),
              padding: EdgeInsets.only(left: 20, right: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Colors.grey[300],
                boxShadow: [
                  BoxShadow(
                      offset: Offset(0, 3), blurRadius: 10, color: Colors.grey)
                ],
              ),
              alignment: Alignment.center,
              child: TextFormField(
                obscureText: obs,
                focusNode: FocusContrasena,
                controller: ContrasenaController,
                cursorColor: Colors.lightBlue.shade900,
                decoration: InputDecoration(
                  icon: Icon(
                    Icons.vpn_key,
                    color: Colors.lightBlue.shade900,
                  ),
                  hintText: "Contraseña",
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  suffixIcon: IconButton(
                    icon: Icon(
                      Icons.remove_red_eye,
                      color: Colors.lightBlue.shade900,
                    ),
                    onPressed: () {
                      setState(() {
                        obs == false ? obs = true : obs = false;
                      });
                    },
                  ),
                ),
              ),
            ),
            //------------------------------------------------------------------
            //BOTON REGISTRAR
            GestureDetector(
              onTap: () => {ConsultaEspecifica()},
              child: Container(
                margin: EdgeInsets.only(left: 35, right: 35, top: 40),
                padding: EdgeInsets.only(left: 20, right: 20),
                alignment: Alignment.center,
                height: 50,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [Colors.blue, Colors.lightBlue.shade900],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight),
                  borderRadius: BorderRadius.circular(50),
                  boxShadow: [
                    BoxShadow(
                        offset: Offset(0, 3),
                        blurRadius: 10,
                        color: Colors.grey)
                  ],
                ),
                child:
                    Text("REGISTRARME", style: TextStyle(color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
